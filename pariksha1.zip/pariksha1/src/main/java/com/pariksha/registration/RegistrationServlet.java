package com.pariksha.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegisterServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String u_first_name = request.getParameter("fname");
		String u_last_name = request.getParameter("lname");
		String u_email = request.getParameter("email");
		String u_password = request.getParameter("password");
		String re_u_password = request.getParameter("re-password");
		RequestDispatcher dispatcher = null;
		Connection con = null;
		
		if(u_first_name == null || u_first_name.equals("")) {
			request.setAttribute("status","invalidfname");
			dispatcher = request.getRequestDispatcher("registration.jsp");
			dispatcher.forward(request, response);
		}
		if(u_last_name == null || u_last_name.equals("")) {
			request.setAttribute("status","invalidlname");
			dispatcher = request.getRequestDispatcher("registration.jsp");
			dispatcher.forward(request, response);
		}
		if(u_email == null || u_email.equals("")) {
			request.setAttribute("status","invalidEmail");
			dispatcher = request.getRequestDispatcher("registration.jsp");
			dispatcher.forward(request, response);
		}
		if(u_password == null || u_password.equals("")) {
			request.setAttribute("status","invalidpassword");
			dispatcher = request.getRequestDispatcher("registration.jsp");
			dispatcher.forward(request, response);
		}else if(!u_password.equals(re_u_password)) {
			request.setAttribute("status","invalidconfirmpassword");
			dispatcher = request.getRequestDispatcher("registration.jsp");
			dispatcher.forward(request, response);
		}
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
		    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pariksha?useSSL=false", "root", "Prakruti@18");
			PreparedStatement pst = con.prepareStatement("insert into users(u_first_name,u_last_name,u_email,u_password) values(?,?,?,?)");
			pst.setString(1,u_first_name);
			pst.setString(2,u_last_name);
			pst.setString(3,u_email);
			pst.setString(4,u_password);
			
			int rowcount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("registration.jsp");
			if(rowcount > 0){
				request.setAttribute("status", "success");
			}
			else {
				request.setAttribute("status", "failed");
			}
			dispatcher.forward(request, response);
		}
		 catch (Exception e){
			 e.printStackTrace();
		 }finally {
			 try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		
		}

}

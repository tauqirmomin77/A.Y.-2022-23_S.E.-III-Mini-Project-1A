/**
 * 
 */
/**
 * @author praniv warungshe
 *
 */
module smart_deals {
	requires java.desktop;
    requires java.sql;
}
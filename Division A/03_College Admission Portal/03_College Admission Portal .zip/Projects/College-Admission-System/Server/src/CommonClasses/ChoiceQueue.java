package CommonClasses;

import java.io.Serializable;
import java.util.Vector;

public class ChoiceQueue implements Serializable{

	private static final long serialVersionUID = -8872851298251854525L;
	public Vector<Choice> choice;
}

package CommonClasses;

import java.io.Serializable;
import java.util.HashMap;

public class ServerCollection implements Serializable{

	private static final long serialVersionUID = 1L;
	public static HashMap<Choice,Integer> H5;
}

package AdminSide;
import java.io.Serializable;

public class AdminInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	public String name;
	public String password;
	public String nickname;
}

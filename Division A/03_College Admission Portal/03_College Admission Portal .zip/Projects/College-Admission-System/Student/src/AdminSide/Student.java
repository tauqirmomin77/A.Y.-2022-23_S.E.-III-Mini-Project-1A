package AdminSide;

public class Student {

	public String name,address,dob,nickname,marks,mob,password,result;
	public Student(String name,String address,String dob,String nickname,String marks,String mob,String password)
	{
		this.name=name;
		this.address=address;
		this.dob=dob;
		this.nickname=nickname;
		this.marks=marks;
		this.mob=mob;
		this.password=password;
	}
}

package CommonClasses;

import java.util.HashMap;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;

public class ServerCollection {

	public static HashMap<Choice,Integer> H5=new HashMap<Choice,Integer>();
	public static HashMap<College,Vector<Branch>> H4=new HashMap<College,Vector<Branch>>();
	public static Vector<Choice> choice;
	public static String text;
	public static JButton b1,b2,b3;
	public static JPanel p1,p2,p3;
	public static JLabel l1,l2,l3,l4,l5;
	public static JTextPane t1;
}

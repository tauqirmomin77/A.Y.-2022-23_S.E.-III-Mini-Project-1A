package CommonClasses;


public class PriorityChoices{

		public Choice Ch;
		public int priority;
		public PriorityChoices(Choice C,int I)
		{
			Ch=C;
			priority=I;
		}
	}
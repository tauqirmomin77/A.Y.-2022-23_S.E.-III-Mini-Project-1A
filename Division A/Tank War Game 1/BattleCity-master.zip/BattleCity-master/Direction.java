
public enum Direction {  
	L, U,  R,  D,  STOP
}

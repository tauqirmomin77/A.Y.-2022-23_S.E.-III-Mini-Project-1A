package com.miniproject.Backend;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class homecontroller {
	
	@GetMapping("/")
    public User getUserData(User homeuser)
 { 	
		return homeuser;
 }

	

}
 
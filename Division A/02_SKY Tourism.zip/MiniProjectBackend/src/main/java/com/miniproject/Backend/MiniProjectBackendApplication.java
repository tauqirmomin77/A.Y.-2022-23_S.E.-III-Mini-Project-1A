package com.miniproject.Backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniProjectBackendApplication {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		SpringApplication.run(MiniProjectBackendApplication.class, args);
		


		String url = "jdbc:mysql://localhost:3306/user";
		String username = "root";
		String pass = "7677";

		String query = "select * from user1";

		// SpringApplication.run(SkyApplication.class, args);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);

		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);

		while (rs.next()) {
			// String name = rs.getString("u_name");
			System.out.println(rs.getString("u_name"));
		}
	//	st.close(); // statement.close
		con.close(); // connection.close

	
	}

}

package com.miniproject.Backend;

public class User {
	private String Uname;
	private String C_loc;
	private String Uemail;
	private String Upassword;

	public String getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		this.Uname = uname;
	}

	public String getC_loc() {
		return C_loc;
	}

	public void setC_loc(String c_loc) {
		this.C_loc = c_loc;
	}

	public String getUemail() {
		return Uemail;
	}

	public void setUemail(String uemail) {
		this.Uemail = uemail;
	}

	public String getUpassword() {
		return Upassword;
	}

	public void setUpassword(String upassword) {
		this.Upassword = upassword;
	}

	@Override
	public String toString() {
		return "User [Uname=" + Uname + ", C_loc=" + C_loc + ", Uemail=" + Uemail + ", Upassword=" + Upassword + "]";
	}

}

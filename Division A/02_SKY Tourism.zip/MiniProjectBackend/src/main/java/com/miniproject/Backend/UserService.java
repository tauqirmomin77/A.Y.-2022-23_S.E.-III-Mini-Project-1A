package com.miniproject.Backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Value("${spring.datasource.url}")
	private String dbUrl;

	@Value("${spring.datasource.username}")
	private String dbUserName;

	@Value("${spring.datasource.password}")
	private String dbPass;

	public User register(User user) {

		// Validations
		if (user == null || user.getUname() == null || user.getUname().isBlank() || user.getUpassword() == null
				|| user.getUpassword().isBlank()) {
			return null;
		}

		Connection conn = null;
		PreparedStatement preparedStatement = null;

		// Database operations
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println(dbUrl + "-" + dbUserName + "-" + dbPass);
			conn = DriverManager.getConnection(dbUrl, dbUserName, dbPass);
			preparedStatement = conn
					.prepareStatement("insert  into user1 (`u_name`,`u_email`,`u_add`,`u_password`) values (?,?,?,?)");

			preparedStatement.setString(1, user.getUname());
			preparedStatement.setString(2, user.getUemail());
			preparedStatement.setString(3, user.getC_loc());
			preparedStatement.setString(4, user.getUpassword());

			// execute Query
			int count = preparedStatement.executeUpdate();

			if (count > 0) {
				return user;
			} else {
				return null;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// release external resources or close connection
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	public String login(String email, String pass) throws SQLException, ClassNotFoundException {
		// Validations
		if (email == null || pass == null) {
			return null;
		}
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		// Database operations
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbUrl, dbUserName, dbPass);
			preparedStatement = conn.prepareStatement("select * from user1 where u_email=? ");
			preparedStatement.setString(1, (email));
			rs = preparedStatement.executeQuery();
		   
			
//			while(rs.next()) {
//				if(rs == )) {
//				
//				}
//			}
			
		
			if(rs.next() && pass.equals(rs.getString(5))){
			System.out.println("successfull"+ rs.getString(2)+rs.getString(5));
			}
			else {
				return "invalid";
			}

		} finally {
			// release external resources or close connection
			try {
				if (rs != null) {
					rs.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
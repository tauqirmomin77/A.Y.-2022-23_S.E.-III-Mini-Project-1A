package dev.srr.musicplayer;

import java.awt.Color;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Animation 
{
	JFrame frmAnimate;
	ImageIcon iconAnimateSRRplayer, iconSRRplayerIntro;
	JLabel lblSRRplayer;
	
	int width = 350;
	int height = 250;
	
	public void animate()
	{
		// create constructor 
		frmAnimate = new JFrame();
		frmAnimate.setSize(width, height);
		frmAnimate.setUndecorated(true);
		frmAnimate.setLayout(null);
		frmAnimate.setLocationRelativeTo(null);
		// add image to icon button
		iconAnimateSRRplayer  = new ImageIcon("src/assets/src/assets/LogoBaajaPNG.png");
		Image imageAnimateBaaja = iconAnimateSRRplayer.getImage();
		iconAnimateSRRplayer.setImage(imageAnimateBaaja);
		frmAnimate.setIconImage(imageAnimateBaaja);
		// add image to icon button
		iconSRRplayerIntro = new ImageIcon("src/assets/LogoBaajaPNG.png");
		Image imgBaajaAnimateIntro = iconSRRplayerIntro.getImage();
		imgBaajaAnimateIntro = imgBaajaAnimateIntro.getScaledInstance(width, height, Image.SCALE_DEFAULT);
		iconSRRplayerIntro.setImage(imgBaajaAnimateIntro);
		//add values into the object
		lblSRRplayer = new JLabel(iconSRRplayerIntro);
		lblSRRplayer.setBounds(0, 0, width, height);
		lblSRRplayer.setLayout(null);
		frmAnimate.getContentPane().add(lblSRRplayer);
		frmAnimate.setBackground(Color.black);
		
		frmAnimate.setVisible(true);
		
		new Thread()
		{
			public void run()
			{
				try
				{       // points to the SRRplayerclass
					SRRplayer objBaaja = new SRRplayer();
			
					sleep(1500);
					objBaaja.init();
					frmAnimate.dispose();
				}
				catch (Exception e) {}
			}
		}.start();
	}//function animate() closed here
}

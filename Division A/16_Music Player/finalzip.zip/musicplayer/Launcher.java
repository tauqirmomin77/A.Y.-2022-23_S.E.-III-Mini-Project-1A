package dev.srr.musicplayer;

public class Launcher 
{
	public static void main(String[] ar)
	{//launches the code and points to animatiion class
		Animation objAnimation = new Animation();
		objAnimation.animate();
	}
}
import java.io.IOException;
import java.io.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;

public class clientLogin extends HttpServlet {
 private static final long serialVersionUID = 1L;

 protected void doPost(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  String name = request.getParameter("clientName");

  String password = request.getParameter("clientPassword");

  try {
   Class.forName("com.mysql.jdbc.Driver");
   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/FreeLation","root","bharatsharma@htmlpp123");
   PreparedStatement pst = conn.prepareStatement("Select clientName,clientPassword from client_signup where clientName=? and clientPassword=?");
   pst.setString(1, name);
   pst.setString(2, password);
   ResultSet rs = pst.executeQuery();
   if (rs.next()) {
    HttpSession hs = request.getSession();
    hs.setAttribute("cname", name);
//    hs.setAttribute("clientPassword", password);
       response.sendRedirect("afterClientLogin.jsp");
    out.println("Username or Password incorrect");
   } else {

    out.println("Username or Password incorrect");

   }
  } catch (ClassNotFoundException | SQLException e) {
   e.printStackTrace();
  }
 }
}


import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class  clientPostProject extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();       
        String ClientName = request.getParameter("clientName");
        String ClientEmail = request.getParameter("clientEmail");
        String clientWantsProjectType = request.getParameter("clientWantsProjectType");
        int clientProjectReturnDate = Integer.parseInt(request.getParameter("clientProjectReturnDate"));
        int clientAge = Integer.parseInt(request.getParameter("clientAge"));
        String clientGender = request.getParameter("clientGender");
        String clientRepositories = request.getParameter("clientRepositories");
        String clientWantsWhichApplictaion = request.getParameter("clientWantsWhichApplictaion");
        String clientAboutProject = request.getParameter("clientAboutProject");
        Date registerDateAndTime = new Date();
            
        out.println(ClientName);
        out.println(ClientEmail);
        out.println(clientWantsProjectType); 
        out.println(clientProjectReturnDate);
        out.println(clientAge);
        out.println(clientGender);
        out.println(clientRepositories);
        out.println(clientWantsWhichApplictaion);
        out.println(clientAboutProject);
        out.println(registerDateAndTime);
         
         
            
        
     Connection con=null;
             Statement st=null;
         ResultSet rs=null;
             
             try{
                Class.forName("com.mysql.jdbc.Driver");    
                con=DriverManager.getConnection("jdbc:mysql://localhost/FreeLation","root","bharatsharma@htmlpp123");                                                                                                                                                                                                                                
                st=con.createStatement();
                st.executeUpdate(  "insert into clientPostProject(clientName,clientEmail,clientWantsProjectType,clientProjectReturnDate,clientAge,clientGender,clientRepositories,clientWantsWhichApplictaion,clientAboutProject,clientPostProjectDateAndTime) values('"+ClientName+"','"+ClientEmail+"','"+clientWantsProjectType+"','"+clientProjectReturnDate+"','"+clientAge+"','"+clientGender+"','"+clientRepositories+"','"+clientWantsWhichApplictaion+"','"+clientAboutProject+"','"+registerDateAndTime+"')");

                out.print("Message Send Sucessfully!!!");
             }
             catch(Exception e){
                 out.print(e);
             }           
    }

}










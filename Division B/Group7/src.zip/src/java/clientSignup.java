

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class  clientSignup extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
             response.setContentType("text/html;charset=UTF-8");
             PrintWriter out = response.getWriter();       
        String ClientName = request.getParameter("clientName");
        String ClientEmail = request.getParameter("clientEmail");
        String ClientMessage = request.getParameter("clientPassword");
        
        Date registerDateAndTime = new Date();
            
     Connection con=null;
             Statement st=null;
         ResultSet rs=null;
             
             try{
                Class.forName("com.mysql.jdbc.Driver");
                con=DriverManager.getConnection("jdbc:mysql://localhost/FreeLation","root","bharatsharma@htmlpp123");
                st=con.createStatement();
                st.executeUpdate(  "insert into client_signup(clientName,clientEmail,clientPassword,registerDateAndTime) values('"+ClientName+"','"+ClientEmail+"','"+ClientMessage+"','"+registerDateAndTime+"')");

                out.print("Message Send Sucessfully!!!");
             }
             catch(Exception e){
                 out.print(e);
             }           
    }

}










///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
// */
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.util.Date;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
///**
// *
// * @author bharat sharma
// */
//public class freelancerBidsProject extends HttpServlet {
//
//    /**
//     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
//     * methods.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        try ( PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet freelancerBidsProject</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet freelancerBidsProject at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
//    }
//
//}
//
//
//



import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class  freelancerBidsProject extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();       
        String FreelancerName = request.getParameter("freelancerEmail");
        String ClientName = request.getParameter("clientEmail");
        String Domain = request.getParameter("domain");
        String PriceRange = request.getParameter("techStack");
        String  TechStack= request.getParameter("priceRange");
        Date registerDateAndTime = new Date();
            
               
     Connection con=null;
             Statement st=null;
         ResultSet rs=null;
             
             try{
                Class.forName("com.mysql.jdbc.Driver");    
                con=DriverManager.getConnection("jdbc:mysql://localhost/FreeLation","root","bharatsharma@htmlpp123");                                                                                                                                                                                                                                
                st=con.createStatement();
                st.executeUpdate(  "insert into freelancerBidsProject(freelancerName,clientEmail,Domain,techStack,priceRange,registerDateAndTime) values('"+FreelancerName+"','"+ClientName+"','"+Domain+"','"+PriceRange+"','"+TechStack+"','"+registerDateAndTime+"')");

                out.print("Message Send Sucessfully!!!");
             }
             catch(Exception e){
                 out.print(e);
             }           
    }

}











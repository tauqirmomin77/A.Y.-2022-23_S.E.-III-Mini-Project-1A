import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.sql.*;  
    
public class freelancerBidClient extends HttpServlet  
{    
     public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
      {  
         PrintWriter out = res.getWriter();  
         res.setContentType("text/html");  
         out.println("<html><body>");  
//         try 
//         {  
//             Class.forName("com.mysql.jdbc.Driver");  
//             Connection con = DriverManager.getConnection("jdbc:mysql://localhost/FreeLation","root","bharatsharma@htmlpp123");  
//             Statement stmt = con.createStatement();  
//             ResultSet rs = stmt.executeQuery("select * from clientPostProject");  
//             out.println("<table border=1 width=50% height=50%>");  
//             out.println("<head><link rel='url icon' href='Images/url_icon.png'><title>Bid</title></head><tr><th>EmpId</th><th>EmpName</th><th>Tech Stack </th><th>clientProjectReturnDate</th><th>Age</th><th>Repositorie</th><th>Domain</th><th>About Project</th><th>Posted On</th><tr>");  
//             
//             while (rs.next()) 
//             {  
//                 String clientName = rs.getString("clientName");  
//                 String clientEmail = rs.getString("clientEmail");  
//                 String clientWantsProjectType = rs.getString("clientWantsProjectType"); 
//                 int clientProjectReturnDate = Integer.parseInt(rs.getString("clientProjectReturnDate"));
//                 int clientAge = Integer.parseInt(rs.getString("clientAge"));
//                 String clientWantsWhichApplictaion = rs.getString("clientWantsWhichApplictaion"); 
//                 String clientRepositories = rs.getString("clientRepositories"); 
//                 String clientAboutProject = rs.getString("clientAboutProject"); 
//                 String clientPostProjectDateAndTime = rs.getString("clientPostProjectDateAndTime"); 
//                 
//                 out.println("<tr><td>" + clientName + "</td><td>" + clientEmail + "</td><td>" + clientWantsProjectType + "</td><td>" + clientProjectReturnDate + "</td><td>" + clientAge + "</td><td>" + clientRepositories + "</td><td>" + clientWantsWhichApplictaion + "</td><td>" + clientAboutProject + "</td><td>" + clientPostProjectDateAndTime +"</td></tr>");   
//             }  
//             out.println("</table>");  
//             out.println("</html></body>");  
//             con.close();  
//            }  
//             catch (Exception e) 
//            {  
//             out.println("error");  
//         }  

 try{
             req.getRequestDispatcher("bid.jsp").forward(req, res);
         }
             catch (Exception e) 
            {  
             out.println(e);  
         } 
     }  
 }  